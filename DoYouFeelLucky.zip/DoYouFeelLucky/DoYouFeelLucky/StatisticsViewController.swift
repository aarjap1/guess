//
//  StatisticsViewController.swift
//  DoYouFeelLucky
//
//  Created by Piya,Aarjap Kumar on 2/27/19.
//  Copyright © 2019 Piya,Aarjap Kumar. All rights reserved.
//

import UIKit

class StatisticsViewController: UIViewController {
    
    
    @IBOutlet weak var minLBL: UILabel!
    @IBOutlet weak var maxLBL: UILabel!
    @IBOutlet weak var meanLBL: UILabel!
    @IBOutlet weak var sdvLBL: UILabel!
    
    @IBAction func clearStat(_ sender: Any) {
        Guesser.share.clearStatistics()
        minLBL.text = "0"
        maxLBL.text = "0"
        meanLBL.text = "0"
        sdvLBL.text = "0"
    }
    
   
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
      
   
        
        
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        minLBL.text = "\( Guesser.share.minimumNumAttempts())"
        maxLBL.text = "\(Guesser.share.maximumNumAttempts())"
        var sum:Int = 0
        for i in 0 ..< Guesser.share.numGuesses(){
            sum += Guesser.share.guess(index: i).numAtReq
            
        }
        let mean:Double = Double(sum)/Double(Guesser.share.numGuesses())
        meanLBL.text = String(mean)
        
        var sd: Double = 0.0
        for i in 0 ..< Guesser.share.numGuesses(){
            sd += pow(Double(Guesser.share.guess(index: i).numAtReq)-mean, 2)
        }
        sdvLBL.text = String(sd)
        
        }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
