//
//  FirstViewController.swift
//  DoYouFeelLucky
//
//  Created by Piya,Aarjap Kumar on 2/27/19.
//  Copyright © 2019 Piya,Aarjap Kumar. All rights reserved.
//
import UIKit


class FirstViewController: UIViewController {
    
    var guesser: Guesser!
    
    
    @IBOutlet weak var guessTxt: UITextField!
    
    @IBOutlet weak var resultLBL: UILabel!
    
    
    @IBAction func checkAnswer(_ sender: Any) {
        let guess = (Int(guessTxt.text!) ?? 0)
        if (guess > 0 && guess < 11){
            if (Guesser.share.amIRight(guess: guess) == .correct){
                displayMessage()
            }
            else{
                resultLBL.text = "\(Guesser.share.amIRight(guess: guess))"
            }
            
        }
        
        else{
            resultLBL.text = "Enter number between 1 and 10 (Inclusive)"
        }
        
    }
    
    
    
    @IBAction func newProblem(_ sender: Any) {
        Guesser.share.createNewProblem()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    
    func displayMessage(){
        let alert = UIAlertController(title: "Well done",
                                      message: "You got it in \(Guesser.share.numAttemps) tries", 
            preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default,  
                                      handler: nil))
        self.present(alert, animated: true, completion: nil)
    }


}

