//
//  Guesser.swift
//  DoYouFeelLucky
//
//  Created by Piya,Aarjap Kumar on 2/27/19.
//  Copyright © 2019 Piya,Aarjap Kumar. All rights reserved.
//

import Foundation

    struct Guess{
        var correctAnswer:Int
        var numAtReq: Int
    }
    
    class Guesser{
        
        public static var share = Guesser()
        private var correctAnswer: Int
        private var _numAt : Int
        private var guesses: [Guess] = []
        
        public var numAttemps:Int{
            return _numAt
        }
        
        
        private init(correctAnswer:Int, _numAttemps:Int, guesses:[Guess]){
            self.correctAnswer = correctAnswer
            self._numAt = _numAttemps
            self.guesses = guesses
        }
        private convenience init(correctAnswer:Int, guesses:[Guess]){
            self.init(correctAnswer:correctAnswer, _numAttemps: 0, guesses:guesses)
            
        }
        
        private convenience init(){
            self.init(correctAnswer:Int(arc4random_uniform(10)) + 1, _numAttemps: 0, guesses: [] )
            
        }
       
        func createNewProblem(){
            var newAnswer: Int
                newAnswer = Int(arc4random_uniform(10)) + 1
//            self.correctAnswer = newAnswer
//            self._numAttempts = 0
            Guesser.share = Guesser(correctAnswer: newAnswer, guesses:Guesser.share.guesses)
        }
        
        func amIRight(guess:Int) -> Result{
            _numAt += 1
            if (guess>self.correctAnswer){
                return .tooHigh
            }
            else if (guess<self.correctAnswer){
                return .tooLow
            }
            else{
                guesses += [Guess(correctAnswer: correctAnswer, numAtReq: _numAt)]
                return .correct
            }
        }
        
        func guess(index:Int) -> Guess {
            return Guesser.share.guesses[index]
        }
        func numGuesses() -> Int{
            return guesses.count
        }
        
        func clearStatistics(){
            Guesser.share = Guesser()
        }
        
        func minimumNumAttempts() -> Int{
            var minimum = guesses[0].numAtReq
            for guess in guesses{
                if (minimum > guess.numAtReq){
                    minimum = guess.numAtReq
                }
            }
            return minimum
        }
      
        func maximumNumAttempts() -> Int{
            var maximum = guesses[0].numAtReq
            for guess in guesses{
                if (maximum < guess.numAtReq){
                    maximum = guess.numAtReq
                }
            }
            return maximum
        }
        }
    

    enum Result:String {case tooLow = " Too Low", tooHigh = " Too High", correct = " Correct"}
    
 
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


