//
//  Guesser1.swift
//  DoYouFeelLucky
//
//  Created by student on 2/27/19.
//  Copyright © 2019 student. All rights reserved.
//

import UIKit

class Guesser1: NSObject {

}
