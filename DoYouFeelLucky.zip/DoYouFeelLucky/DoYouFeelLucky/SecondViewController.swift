//
//  SecondViewController.swift
//  DoYouFeelLucky
//
//  Created by Piya,Aarjap Kumar on 2/27/19.
//  Copyright © 2019 Piya,Aarjap Kumar. All rights reserved.
//

import UIKit



class SecondViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Guesser.share.numGuesses()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "History" , for: indexPath)
      
        
        let correctAnswerLBL = cell.viewWithTag(5) as! UILabel
        let attemptLBL = cell.viewWithTag(10) as! UILabel
       
        
        correctAnswerLBL.text = String(Guesser.share.guess(index: indexPath.row).correctAnswer)
        attemptLBL.text = String(Guesser.share.guess(index: indexPath.row).numAtReq)
        
        return cell
    }
    
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

